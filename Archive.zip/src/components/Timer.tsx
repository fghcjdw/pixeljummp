import React, { useState, useEffect } from 'react';
import { useGame } from '../lib/stores/useGame';

export function Timer() {
  const { phase, getCurrentTime, bestTimes, currentLevel } = useGame();
  const [currentTime, setCurrentTime] = useState(0);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (phase === 'playing') {
      interval = setInterval(() => {
        setCurrentTime(getCurrentTime());
      }, 100); // Update every 100ms for smooth display
    }

    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, [phase, getCurrentTime]);

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = (seconds % 60).toFixed(1);
    return mins > 0 ? `${mins}:${secs.padStart(4, '0')}` : `${secs}s`;
  };

  const bestTime = bestTimes[currentLevel];

  if (phase !== 'playing') {
    return null;
  }

  return (
    <div style={{
      position: 'absolute',
      top: '20px',
      left: '50%',
      transform: 'translateX(-50%)',
      backgroundColor: 'rgba(0,0,0,0.8)',
      padding: '10px 20px',
      borderRadius: '8px',
      fontSize: '16px',
      fontWeight: 'bold',
      color: '#fff',
      fontFamily: 'Inter, monospace',
      pointerEvents: 'none',
      border: '2px solid #444'
    }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{ color: '#FFD700', marginBottom: '2px' }}>
          ⏱️ {formatTime(currentTime)}
        </div>
        {bestTime && (
          <div style={{ color: '#4CAF50', fontSize: '12px' }}>
            Best: {formatTime(bestTime)}
          </div>
        )}
        {!bestTime && (
          <div style={{ color: '#888', fontSize: '12px' }}>
            First attempt
          </div>
        )}
      </div>
    </div>
  );
}